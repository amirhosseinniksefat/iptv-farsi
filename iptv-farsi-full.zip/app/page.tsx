export default function Home() {
  return (
    <main className="p-4 text-right">
      <h1 className="text-3xl font-bold mb-4">تلویزیون زنده</h1>
      <p className="text-gray-700">لیستی از کانال‌های زنده در دسترس.</p>
    </main>
  );
}
